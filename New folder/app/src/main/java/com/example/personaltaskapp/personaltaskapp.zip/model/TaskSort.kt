package com.example.personaltaskapp.model

enum class TaskSort(val displayName: String) {
    TITLE_ASC("Title Ascending"),
    TITLE_DESC("Title Descending")
}