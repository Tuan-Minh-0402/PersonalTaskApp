package com.example.personaltaskapp.model

enum class PomodoroState {
    WORK,
    SHORT_BREAK,
    LONG_BREAK,
    IDLE
}
